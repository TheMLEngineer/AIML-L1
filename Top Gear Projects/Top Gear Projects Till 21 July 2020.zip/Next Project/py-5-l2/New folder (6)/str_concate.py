a,b= input("Enter the string:"),input("Enter the string:")
str=a+b+b+a

print "\nNew string is:",str
  
    
