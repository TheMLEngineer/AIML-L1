str1 = input("Enter the string:")
print str1
str2 = str1.replace(str1[0],'I')
print "Replaced string is:",str2
