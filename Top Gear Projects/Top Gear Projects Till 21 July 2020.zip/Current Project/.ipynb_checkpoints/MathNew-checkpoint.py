import math

def find_square_root(number):
    if isinstance(number , int) or isinstance(number , float):
        return math.sqrt(number)
    else:
        return 'Please Provide Proper Numeric Type'
    
def addition_of_two_numbers(number1 , number2):
    if (isinstance(number1 , int) or isinstance(number2 , float)) and (isinstance(number1 , int) or isinstance(number2 , float)):
        return number1 + number2
    else:
        return 'Please Provide Valid Numeric types to Add'
    
def substraction_of_two_numbers(number1 , number2):
    if (isinstance(number1 , int) or isinstance(number2 , float)) and (isinstance(number1 , int) or isinstance(number2 , float)):
        return number1 - number2
    else:
        return 'Please Provide Valid Numeric types to Add'
    
def multiplication_of_two_numbers(number1 , number2):
    if (isinstance(number1 , int) or isinstance(number2 , float)) and (isinstance(number1 , int) or isinstance(number2 , float)):
        return number1 * number2
    else:
        return 'Please Provide Valid Numeric types to Add'
    
def division_of_two_numbers(number1 , number2):
    if (isinstance(number1 , int) or isinstance(number2 , float)) and (isinstance(number1 , int) or isinstance(number2 , float)):
        return number1 / number2
    else:
        return 'Please Provide Valid Numeric types to Add'
    
